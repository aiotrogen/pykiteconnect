def att():
    at = 'put yout access token here'
    return at

def atp():
    ap = 'api key here'
    return ap