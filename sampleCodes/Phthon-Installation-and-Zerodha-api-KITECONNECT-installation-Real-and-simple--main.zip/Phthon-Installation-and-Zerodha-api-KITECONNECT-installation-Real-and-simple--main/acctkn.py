#!C:\Users\WinWinTrader\AppData\Local\Programs\Python\Python38\python.exe

def att():
    at = 'put yout access token here'
    return at

def atp():
    ap = 'api key here'
    return ap
