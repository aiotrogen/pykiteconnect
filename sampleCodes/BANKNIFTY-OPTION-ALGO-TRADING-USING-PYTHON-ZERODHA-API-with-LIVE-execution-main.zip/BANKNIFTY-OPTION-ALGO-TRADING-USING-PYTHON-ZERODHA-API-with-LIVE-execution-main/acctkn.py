#!c:\users\pcuser1.pcuser1-pc\appdata\local\programs\python\python38\python.exe

def att():
    at = 'put yout access token here'
    return at

def atp():
    ap = 'api key here'
    return ap
